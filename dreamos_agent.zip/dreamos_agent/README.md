# 🧠 DreamOS Agent

A **local, privacy-first AI assistant** that deeply understands your codebase — explains architecture, detects bugs automatically, and answers questions, all without sending your code to the cloud.

---

## ✨ Features

| Feature | Status |
|---|---|
| Python AST parsing (functions, classes, imports) | ✅ MVP |
| Automatic bug detection (15+ patterns) | ✅ MVP |
| Architecture summaries | ✅ MVP |
| Dependency analysis + circular dep detection | ✅ MVP |
| Conversational Q&A via Ollama | ✅ MVP |
| Safe shell command execution | ✅ MVP |
| File read/edit with backup | ✅ MVP |
| Git blame, log, diff | ✅ MVP |
| Long-term memory across sessions | ✅ MVP |
| Multi-language support (tree-sitter) | 🔜 Phase 2 |
| Call graph construction | 🔜 Phase 2 |
| Multi-step task planning | 🔜 Phase 3 |

---

## 🚀 Quick Start

### 1. Prerequisites

```bash
# Install Ollama (local LLM runner)
curl -fsSL https://ollama.com/install.sh | sh

# Pull a model (llama3 is recommended)
ollama pull llama3
```

### 2. Install DreamOS Agent

```bash
# From source
git clone <repo>
cd dreamos_agent
pip install -e .

# Or run directly
python main.py
```

### 3. Run it

```bash
# Analyze current directory
python main.py

# Analyze a specific project
python main.py --workspace ~/myproject

# No Ollama? Just get the analysis
python main.py --no-llm

# Only want the bug report?
python main.py --bugs-only

# Architecture overview only?
python main.py --arch-only
```

---

## 💬 Example Session

```
you › overview
📦 Project: myapp
🗂  Files: 12 modules
⚙️  Functions: 47 | Classes: 8
📊 Avg Complexity: 3.4
🔧 Framework: fastapi
🚀 Entry Points: main.py, app.py

🔥 Most Complex Functions:
  • process_request (handlers.py:42) — complexity 14
  • validate_schema (validators.py:18) — complexity 11

you › bugs
🐛 Bug Report — 6 issue(s) found
[CRITICAL] security
  🔴 Hardcoded API key detected.
     📍 config.py:7
     💡 Fix: Use environment variables or a secrets manager.

you › explain process_request
⚙️  Function: def process_request(req, ctx)
   Location: handlers.py:42
   Complexity: 14
   Calls: validate, log_event, send_response

you › Why is process_request so complex?
agent › process_request has complexity 14, which is above the recommended threshold of 10.
Looking at handlers.py:42, it handles 7 different error conditions inline...
[continues with LLM analysis]
```

---

## 🏗️ Architecture

```
dreamos_agent/
├── core/              # Domain models (single source of truth)
│   ├── models.py      # CodeEntity, Function, Class, Module, Project, Bug
│   └── repository.py  # Save/load/query domain models
├── analyzers/         # Code understanding engines
│   ├── ast_analyzer.py     # Python AST → domain models
│   ├── bug_detector.py     # Pattern + AST bug detection
│   └── dependency_analyzer.py  # Import graphs, circular deps
├── llm/               # LLM interface
│   ├── client.py      # Ollama wrapper
│   └── prompts.py     # Prompt templates per query type
├── tools/             # Action execution
│   ├── shell.py       # Safe command runner
│   ├── files.py       # File read/write/edit
│   └── git.py         # Git blame, log, diff
├── agent/             # Orchestration
│   └── orchestrator.py    # Routes queries, manages state
├── interfaces/        # User-facing UIs
│   └── cli.py         # Terminal chat interface
└── main.py            # Entry point + CLI args
```

---

## 🐛 Detected Bug Patterns

The bug detector runs **without any LLM** — instant, deterministic results:

- 🔴 **CRITICAL**: Hardcoded passwords, secrets, API keys; `eval()`/`exec()`
- 🟠 **HIGH**: Bare `except:`, mutable default arguments, high cyclomatic complexity
- 🟡 **MEDIUM**: Wildcard imports, nested loops, files opened without context manager
- 🔵 **LOW**: `print()` debugging left in code, too many return statements
- ⚪ **INFO**: TODO/FIXME/HACK comments

---

## ⚙️ CLI Commands

### Instant (no LLM)
| Command | Description |
|---|---|
| `bugs` | Full bug report |
| `arch` / `overview` | Architecture summary |
| `deps` | Dependency analysis |
| `read <path>` | Read a file |
| `search <term>` | Search code |
| `run <cmd>` | Execute safe shell command |
| `explain <name>` | Explain function/class/module |
| `git log` | Recent commits |
| `git status` | Working tree status |
| `memory` | Recall past session insights |

### Natural Language (uses Ollama)
- *"What does this project do?"*
- *"Why is X function so complex?"*
- *"Which files should I refactor first?"*
- *"How does the authentication flow work?"*
- *"Explain the relationship between X and Y"*

---

## 🔒 Privacy & Security

- **Zero cloud calls** — everything runs locally via Ollama
- **Command sandboxing** — only whitelisted shell commands allowed
- **Workspace isolation** — file tool cannot access paths outside your project
- **No telemetry** — no tracking, no phoning home

---

## 📋 System Requirements

| Component | Minimum | Recommended |
|---|---|---|
| Python | 3.10+ | 3.11+ |
| RAM | 4 GB | 8 GB+ |
| Disk | 2 GB | 10 GB (for LLM models) |
| Ollama | Optional | Required for Q&A |

---

## 🗺️ Roadmap

- **Phase 2**: Multi-language (JS/TS/Go/Rust), call graphs, cross-file analysis
- **Phase 3**: Multi-step planning, automated refactoring, test generation
- **Phase 4**: Web UI, voice interface, plugin system
