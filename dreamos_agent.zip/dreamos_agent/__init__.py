"""
DreamOS Agent
A local, conversational desktop agent that deeply understands your codebase.
"""

__version__ = "1.0.0"
__author__ = "DreamOS"

from .agent.orchestrator import Orchestrator

__all__ = ["Orchestrator"]
