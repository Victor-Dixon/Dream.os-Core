"""
DreamOS Agent - Orchestrator
Coordinates analyzers, LLM, tools, and memory into a unified response system.
"""

import uuid
from pathlib import Path
from typing import List, Optional, Tuple

from ..analyzers.ast_analyzer import ASTAnalyzer
from ..analyzers.bug_detector import BugDetector
from ..analyzers.dependency_analyzer import DependencyAnalyzer
from ..core.models import Bug, Project, SessionContext
from ..core.repository import DomainRepository, MemoryStore
from ..llm.client import OllamaClient
from ..llm.prompts import SYSTEM_PROMPT, build_prompt, truncate_for_token_limit
from ..tools.files import FileTool
from ..tools.git import GitTool
from ..tools.shell import ShellTool


class Orchestrator:
    """Central coordinator — analyzes, remembers, and answers."""

    def __init__(
        self,
        workspace: str = ".",
        model: str = "llama3",
        verbose: bool = True,
    ):
        self.workspace = Path(workspace).resolve()
        self.verbose = verbose

        # Core components
        self.ast_analyzer = ASTAnalyzer(str(self.workspace))
        self.bug_detector = BugDetector()
        self.dep_analyzer = DependencyAnalyzer()
        self.llm = OllamaClient(model=model)
        self.repo = DomainRepository()
        self.memory_store = MemoryStore()

        # Tools
        self.shell = ShellTool(workspace=str(self.workspace))
        self.files = FileTool(workspace=str(self.workspace))
        self.git = GitTool(workspace=str(self.workspace))

        # Session state
        self.session = SessionContext(session_id=str(uuid.uuid4()))
        self.project: Optional[Project] = None
        self.bugs: List[Bug] = []
        self.architecture_summary = ""
        self.bug_summary = ""
        self.dep_summary = ""

    def _log(self, msg: str):
        if self.verbose:
            print(msg)

    def initialize(self):
        """Analyze the workspace. Run once on startup."""
        self._log("🔍 Scanning codebase with AST analyzer...")
        self.project = self.ast_analyzer.analyze_project()
        self._log(f"✅ Parsed {len(self.project.modules)} modules")

        self._log("🐛 Running bug detection...")
        self.bugs = self.bug_detector.scan_project(self.project)
        self._log(f"   Found {len(self.bugs)} potential issues")

        self.architecture_summary = self.ast_analyzer.get_architecture_summary(self.project)
        self.bug_summary = self.bug_detector.get_bug_summary(self.bugs)
        self.dep_summary = self.dep_analyzer.summary(self.project)

        # Persist results
        self.repo.save_project(self.project)
        self.repo.save_bugs(self.project.name, self.bugs)

        # Load long-term memory
        self.memory = self.memory_store.load(str(self.workspace))
        self.session.current_project = self.project

        self._log(f"\n🧠 DreamOS Agent ready — {self.project.name}")
        return self

    def answer(self, query: str) -> str:
        """Route query to the right handler and return a response."""
        self.session.add_message("user", query)
        q = query.strip().lower()

        # ---- Shortcut commands (no LLM needed) ----
        if q in ("bugs", "issues", "problems"):
            return self.bug_summary

        if q in ("arch", "architecture", "overview", "stats"):
            return self.architecture_summary + "\n\n" + self.dep_summary

        if q in ("deps", "dependencies"):
            return self.dep_summary

        if q.startswith("read "):
            path = query[5:].strip()
            return self.files.read(path)

        if q.startswith("run "):
            cmd = query[4:].strip()
            result = self.shell.run(cmd)
            return result.display()

        if q.startswith("search "):
            term = query[7:].strip()
            return self.files.search(term, extensions=[".py"])

        if q.startswith("explain "):
            target = query[8:].strip()
            return self._explain_component(target)

        if q in ("git log", "log"):
            return self.git.log()

        if q == "git status":
            return self.git.status()

        if q in ("help", "commands", "?"):
            return self._help_text()

        if q in ("memory", "insights"):
            recalled = self.memory.recall(query)
            if recalled:
                return "💭 Remembered from past sessions:\n" + "\n".join(f"  • {i}" for i in recalled)
            return "No relevant memories found."

        # ---- LLM-powered answer ----
        context = truncate_for_token_limit(
            f"{self.architecture_summary}\n\n{self.dep_summary}"
        )
        bug_ctx = truncate_for_token_limit(self.bug_summary, max_chars=2000)
        prompt = build_prompt(query, architecture=context, bug_summary=bug_ctx)

        response = self.llm.generate(prompt, system=SYSTEM_PROMPT)

        # Store as memory insight
        self.memory.add_insight(f"Q: {query[:100]} → discussed")
        self.memory_store.save(self.memory)

        self.session.add_message("assistant", response)
        return response

    def _explain_component(self, target: str) -> str:
        """Find and explain a function, class, or module by name."""
        if not self.project:
            return "Project not analyzed yet. Call initialize() first."

        results = []

        for module in self.project.modules:
            if target in module.name or target in str(module.path):
                results.append(f"📄 Module: {module.name} ({module.path})")
                results.append(f"   Imports: {', '.join(module.imports[:8])}")
                for func in module.functions:
                    results.append(f"   {func.signature}  [complexity: {func.complexity}]")
                for cls in module.classes:
                    results.append(f"   class {cls.name}({', '.join(cls.base_classes)})")
                    for m in cls.methods:
                        results.append(f"     {m.signature}")

            for func in module.all_functions():
                if target == func.name:
                    results.append(f"\n⚙️  Function: {func.signature}")
                    results.append(f"   Location: {module.path}:{func.line_start}")
                    results.append(f"   Complexity: {func.complexity}")
                    if func.docstring:
                        results.append(f"   Docstring: {func.docstring}")
                    if func.calls:
                        results.append(f"   Calls: {', '.join(func.calls[:6])}")

            for cls in module.classes:
                if target == cls.name:
                    results.append(f"\n🏛  Class: {cls.name}")
                    results.append(f"   Location: {module.path}:{cls.line_start}")
                    results.append(f"   Inherits: {', '.join(cls.base_classes) or 'nothing'}")
                    results.append(f"   Methods ({len(cls.methods)}): {', '.join(m.name for m in cls.methods)}")
                    if cls.docstring:
                        results.append(f"   Docstring: {cls.docstring}")

        if not results:
            # Fall back to text search
            search_result = self.files.search(target, extensions=[".py"])
            return f"No direct match for '{target}'. Text search results:\n{search_result}"

        return "\n".join(results)

    def _help_text(self) -> str:
        return """
🧠 DreamOS Agent — Available Commands

INSTANT (no LLM):
  bugs              Show all detected bugs
  arch / overview   Architecture summary
  deps              Dependency analysis
  read <path>       Read a file
  search <term>     Search code for a term
  run <command>     Execute a shell command (safe commands only)
  explain <name>    Explain a function/class/module
  git log           Recent git commits
  git status        Git working tree status
  memory            Recall past session insights

NATURAL LANGUAGE (uses LLM):
  "What does X function do?"
  "Why is Y module so complex?"
  "How does the request flow work?"
  "Which files should I look at first?"
  "Explain the architecture of this project"
  "How can I fix the bug in Z?"

SHORTCUTS:
  exit / quit       Exit the agent
  help / ?          Show this message
"""
