"""
DreamOS Agent - AST Analyzer
Parses Python source files into typed domain models using the built-in `ast` module.
"""

import ast
import re
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from ..core.models import Class, Function, Module, Project


IGNORED_DIRS = {".git", "__pycache__", "venv", ".venv", "env", "node_modules", ".tox", "dist", "build", ".eggs"}
ENTRY_POINT_NAMES = {"main", "app", "run", "server", "cli", "start", "application"}
FRAMEWORK_SIGNALS: Dict[str, List[str]] = {
    "fastapi": ["fastapi", "APIRouter", "FastAPI"],
    "flask": ["flask", "Flask"],
    "django": ["django", "urlpatterns"],
    "click": ["click", "@click.command"],
    "pytest": ["pytest", "conftest"],
}


def _get_complexity(node: ast.FunctionDef) -> int:
    """Cyclomatic complexity: count decision points + 1."""
    complexity = 1
    for child in ast.walk(node):
        if isinstance(child, (
            ast.If, ast.While, ast.For, ast.ExceptHandler,
            ast.With, ast.Assert, ast.comprehension,
        )):
            complexity += 1
        elif isinstance(child, ast.BoolOp):
            complexity += len(child.values) - 1
    return complexity


def _get_docstring(node) -> Optional[str]:
    """Extract docstring from a function/class/module AST node."""
    if (
        isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Module))
        and node.body
        and isinstance(node.body[0], ast.Expr)
        and isinstance(node.body[0].value, ast.Constant)
        and isinstance(node.body[0].value.value, str)
    ):
        return node.body[0].value.value.strip()
    return None


def _get_return_annotation(node: ast.FunctionDef) -> Optional[str]:
    if node.returns:
        try:
            return ast.unparse(node.returns)
        except Exception:
            return None
    return None


def _get_calls(node: ast.FunctionDef) -> List[str]:
    """Get names of functions called within this function."""
    calls = []
    for child in ast.walk(node):
        if isinstance(child, ast.Call):
            if isinstance(child.func, ast.Name):
                calls.append(child.func.id)
            elif isinstance(child.func, ast.Attribute):
                calls.append(child.func.attr)
    return list(set(calls))


class ASTAnalyzer:
    """Parse Python files into domain model Module objects."""

    def __init__(self, root_path: str = "."):
        self.root = Path(root_path).resolve()

    def parse_file(self, filepath: Path) -> Optional[Module]:
        """Parse a single Python file into a Module domain model."""
        try:
            source = filepath.read_text(encoding="utf-8", errors="ignore")
            tree = ast.parse(source)
        except SyntaxError as e:
            # Return a stub module flagging the syntax error
            return Module(
                name=filepath.stem,
                path=filepath,
                docstring=f"SyntaxError: {e}",
            )
        except Exception:
            return None

        lines = source.splitlines()
        module = Module(
            name=filepath.stem,
            path=filepath,
            docstring=_get_docstring(tree),
            language="python",
        )

        for node in ast.walk(tree):
            # --- Imports ---
            if isinstance(node, ast.Import):
                for alias in node.names:
                    module.imports.append(alias.name)

            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    module.imports.append(node.module)

            # --- Top-level functions ---
            elif isinstance(node, ast.FunctionDef) or isinstance(node, ast.AsyncFunctionDef):
                # Only top-level (direct children of module body)
                if any(node is child for child in tree.body):
                    func = self._parse_function(node, filepath, is_method=False)
                    module.functions.append(func)

            # --- Classes ---
            elif isinstance(node, ast.ClassDef):
                if any(node is child for child in tree.body):
                    cls = self._parse_class(node, filepath)
                    module.classes.append(cls)

            # --- Global variables ---
            elif isinstance(node, ast.Assign):
                if any(node is child for child in tree.body):
                    for target in node.targets:
                        if isinstance(target, ast.Name):
                            module.global_vars.append(target.id)

        # Detect entry point
        module.is_entry_point = self._is_entry_point(filepath, module)

        return module

    def _parse_function(
        self, node, filepath: Path, is_method: bool = False
    ) -> Function:
        args = [a.arg for a in node.args.args if a.arg != "self"]
        decorators = []
        for d in node.decorator_list:
            try:
                decorators.append(ast.unparse(d))
            except Exception:
                pass

        end_line = getattr(node, "end_lineno", node.lineno)
        return Function(
            name=node.name,
            path=filepath,
            line_start=node.lineno,
            line_end=end_line,
            args=args,
            returns=_get_return_annotation(node),
            decorators=decorators,
            complexity=_get_complexity(node),
            calls=_get_calls(node),
            is_method=is_method,
            is_async=isinstance(node, ast.AsyncFunctionDef),
            docstring=_get_docstring(node),
        )

    def _parse_class(self, node: ast.ClassDef, filepath: Path) -> Class:
        methods = []
        attributes = []
        is_dataclass = any("dataclass" in ast.unparse(d) for d in node.decorator_list)

        for item in node.body:
            if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                methods.append(self._parse_function(item, filepath, is_method=True))
            elif isinstance(item, ast.Assign):
                for target in item.targets:
                    if isinstance(target, ast.Name):
                        attributes.append(target.id)
            elif isinstance(item, ast.AnnAssign):
                if isinstance(item.target, ast.Name):
                    attributes.append(item.target.id)

        base_classes = []
        for base in node.bases:
            try:
                base_classes.append(ast.unparse(base))
            except Exception:
                pass

        is_abstract = any(b in ("ABC", "ABCMeta") for b in base_classes)
        end_line = getattr(node, "end_lineno", node.lineno)

        return Class(
            name=node.name,
            path=filepath,
            line_start=node.lineno,
            line_end=end_line,
            methods=methods,
            attributes=attributes,
            base_classes=base_classes,
            is_abstract=is_abstract,
            is_dataclass=is_dataclass,
            docstring=_get_docstring(node),
        )

    def _is_entry_point(self, filepath: Path, module: Module) -> bool:
        """Heuristic: is this file likely an entry point?"""
        stem = filepath.stem.lower()
        if stem in ENTRY_POINT_NAMES:
            return True
        if any(f.name == "__main__" for f in module.functions):
            return True
        return False

    def analyze_project(self) -> Project:
        """Scan entire project and produce a Project domain model."""
        project = Project(
            name=self.root.name,
            path=self.root,
        )

        all_source = []

        for filepath in self.root.rglob("*.py"):
            if any(part in IGNORED_DIRS for part in filepath.parts):
                continue
            module = self.parse_file(filepath)
            if module:
                project.modules.append(module)
                all_source.append(filepath.read_text(errors="ignore"))
                if module.is_entry_point:
                    project.entry_points.append(str(filepath.relative_to(self.root)))

        # Detect framework
        combined = "\n".join(all_source[:10])  # quick scan first 10 files
        for fw, signals in FRAMEWORK_SIGNALS.items():
            if any(s in combined for s in signals):
                project.framework = fw
                break

        # Load requirements.txt if present
        req_path = self.root / "requirements.txt"
        if req_path.exists():
            for line in req_path.read_text().splitlines():
                line = line.strip()
                if line and not line.startswith("#"):
                    parts = re.split(r"[>=<!~]", line, 1)
                    pkg = parts[0].strip()
                    ver = line[len(pkg):].strip() if len(parts) > 1 else ""
                    project.dependencies[pkg] = ver

        return project

    def get_architecture_summary(self, project: Project) -> str:
        """Human-readable architecture summary from domain model."""
        stats = project.stats()
        lines = [
            f"📦 Project: {project.name}",
            f"🗂  Files: {stats['modules']} modules",
            f"⚙️  Functions: {stats['functions']} | Classes: {stats['classes']}",
            f"📊 Avg Complexity: {stats['avg_complexity']}",
        ]
        if stats["framework"]:
            lines.append(f"🔧 Framework: {stats['framework']}")
        if stats["entry_points"]:
            lines.append(f"🚀 Entry Points: {', '.join(stats['entry_points'][:3])}")

        # Top complex functions
        complex_funcs = sorted(project.all_functions(), key=lambda f: f.complexity, reverse=True)[:5]
        if complex_funcs:
            lines.append("\n🔥 Most Complex Functions:")
            for f in complex_funcs:
                rel = Path(f.path).name
                lines.append(f"  • {f.name} ({rel}:{f.line_start}) — complexity {f.complexity}")

        # Classes overview
        all_classes = project.all_classes()
        if all_classes:
            lines.append(f"\n🏛  Classes ({len(all_classes)}):")
            for cls in all_classes[:5]:
                lines.append(f"  • {cls.name} [{len(cls.methods)} methods] @ {Path(cls.path).name}:{cls.line_start}")

        return "\n".join(lines)
