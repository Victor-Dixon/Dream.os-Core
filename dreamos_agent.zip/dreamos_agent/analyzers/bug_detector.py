"""
DreamOS Agent - Bug Detector
Automatically detects code issues via AST and regex patterns.
No LLM required for pattern-based detection.
"""

import ast
import re
from pathlib import Path
from typing import List

from ..core.models import Bug, BugCategory, BugSeverity, Module, Project


# ============ Pattern Definitions ============

REGEX_PATTERNS = [
    (
        r"except\s*:",
        BugCategory.PATTERN,
        BugSeverity.HIGH,
        "Bare except clause catches everything including KeyboardInterrupt/SystemExit.",
        "Use 'except Exception as e:' or a specific exception type.",
    ),
    (
        r"def\s+\w+\s*\([^)]*=\s*\[\s*\]",
        BugCategory.PATTERN,
        BugSeverity.HIGH,
        "Mutable default argument (list). The same list is shared across all calls.",
        "Use 'def f(x=None): x = x or []' instead.",
    ),
    (
        r"def\s+\w+\s*\([^)]*=\s*\{\s*\}",
        BugCategory.PATTERN,
        BugSeverity.HIGH,
        "Mutable default argument (dict). The same dict is shared across all calls.",
        "Use 'def f(x=None): x = x or {}' instead.",
    ),
    (
        r"\bprint\s*\(",
        BugCategory.STYLE,
        BugSeverity.LOW,
        "Debug print() left in code.",
        "Replace with logging.debug() or logging.info() for production code.",
    ),
    (
        r"TODO|FIXME|HACK|XXX",
        BugCategory.STYLE,
        BugSeverity.INFO,
        "Unresolved TODO/FIXME/HACK comment found.",
        "Address the comment or create a tracked issue.",
    ),
    (
        r"password\s*=\s*['\"][^'\"]+['\"]",
        BugCategory.SECURITY,
        BugSeverity.CRITICAL,
        "Hardcoded password detected.",
        "Use environment variables or a secrets manager.",
    ),
    (
        r"secret\s*=\s*['\"][^'\"]+['\"]",
        BugCategory.SECURITY,
        BugSeverity.CRITICAL,
        "Hardcoded secret detected.",
        "Use environment variables or a secrets manager.",
    ),
    (
        r"api_key\s*=\s*['\"][^'\"]+['\"]",
        BugCategory.SECURITY,
        BugSeverity.CRITICAL,
        "Hardcoded API key detected.",
        "Use environment variables or a secrets manager.",
    ),
    (
        r"eval\s*\(",
        BugCategory.SECURITY,
        BugSeverity.HIGH,
        "Use of eval() is a security risk — it executes arbitrary code.",
        "Avoid eval(); use ast.literal_eval() for safe expression parsing.",
    ),
    (
        r"exec\s*\(",
        BugCategory.SECURITY,
        BugSeverity.HIGH,
        "Use of exec() is a security risk.",
        "Avoid exec() in production code.",
    ),
    (
        r"assert\s+",
        BugCategory.PATTERN,
        BugSeverity.LOW,
        "Assertion used — these are disabled when Python runs with -O flag.",
        "Use explicit validation with raise for critical checks.",
    ),
    (
        r"import \*",
        BugCategory.STYLE,
        BugSeverity.MEDIUM,
        "Wildcard import pollutes the namespace.",
        "Import only what you need: 'from module import specific_thing'.",
    ),
    (
        r"open\s*\([^)]+\)(?!\s*as)",
        BugCategory.PATTERN,
        BugSeverity.MEDIUM,
        "File opened without context manager.",
        "Use 'with open(...) as f:' to ensure the file is properly closed.",
    ),
]


class BugDetector:
    """Multi-strategy bug detection: regex + AST."""

    def __init__(self, max_function_lines: int = 50, max_returns: int = 5, max_complexity: int = 10):
        self.max_function_lines = max_function_lines
        self.max_returns = max_returns
        self.max_complexity = max_complexity

    # ---- File-Level Scanning ----

    def scan_file(self, filepath: Path) -> List[Bug]:
        bugs: List[Bug] = []
        try:
            source = filepath.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            return bugs

        lines = source.splitlines()

        # Regex-based patterns
        bugs.extend(self._regex_scan(source, lines, str(filepath)))

        # AST-based patterns
        bugs.extend(self._ast_scan(source, str(filepath)))

        return bugs

    def scan_project(self, project: Project) -> List[Bug]:
        """Scan every module in the project."""
        all_bugs: List[Bug] = []
        for module in project.modules:
            all_bugs.extend(self.scan_file(module.path))
        # Also include per-function complexity from domain model
        all_bugs.extend(self._complexity_bugs(project))
        return all_bugs

    # ---- Pattern Strategies ----

    def _regex_scan(self, source: str, lines: List[str], filepath: str) -> List[Bug]:
        bugs = []
        for pattern, category, severity, message, fix in REGEX_PATTERNS:
            for match in re.finditer(pattern, source, re.IGNORECASE | re.MULTILINE):
                line_no = source[: match.start()].count("\n") + 1
                snippet = lines[line_no - 1].strip() if line_no <= len(lines) else ""
                bugs.append(Bug(
                    category=category,
                    severity=severity,
                    message=message,
                    file_path=filepath,
                    line_number=line_no,
                    snippet=snippet,
                    fix_suggestion=fix,
                    detected_by="pattern",
                ))
        return bugs

    def _ast_scan(self, source: str, filepath: str) -> List[Bug]:
        bugs = []
        try:
            tree = ast.parse(source)
        except SyntaxError as e:
            bugs.append(Bug(
                category=BugCategory.SYNTAX,
                severity=BugSeverity.CRITICAL,
                message=f"Syntax error: {e.msg}",
                file_path=filepath,
                line_number=e.lineno or 0,
                snippet=e.text or "",
                fix_suggestion="Fix the syntax error before analysis can continue.",
                detected_by="ast",
            ))
            return bugs

        for node in ast.walk(tree):
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue

            func_name = node.name
            start = node.lineno
            end = getattr(node, "end_lineno", start)
            length = end - start

            # Long function
            if length > self.max_function_lines:
                bugs.append(Bug(
                    category=BugCategory.COMPLEXITY,
                    severity=BugSeverity.MEDIUM,
                    message=f"Function '{func_name}' is {length} lines long (limit: {self.max_function_lines}).",
                    file_path=filepath,
                    line_number=start,
                    fix_suggestion="Break this function into smaller, single-purpose helpers.",
                    detected_by="ast",
                ))

            # Too many return statements
            returns = sum(1 for n in ast.walk(node) if isinstance(n, ast.Return))
            if returns > self.max_returns:
                bugs.append(Bug(
                    category=BugCategory.COMPLEXITY,
                    severity=BugSeverity.LOW,
                    message=f"Function '{func_name}' has {returns} return statements (limit: {self.max_returns}).",
                    file_path=filepath,
                    line_number=start,
                    fix_suggestion="Consolidate return paths or use early-return style consistently.",
                    detected_by="ast",
                ))

            # Nested loops (O(n²) risk)
            for_loops = [n for n in ast.walk(node) if isinstance(n, (ast.For, ast.While))]
            for loop in for_loops:
                nested = [n for n in ast.walk(loop) if isinstance(n, (ast.For, ast.While)) and n is not loop]
                if nested:
                    bugs.append(Bug(
                        category=BugCategory.PERFORMANCE,
                        severity=BugSeverity.MEDIUM,
                        message=f"Nested loops in '{func_name}' — potential O(n²) performance issue.",
                        file_path=filepath,
                        line_number=loop.lineno,
                        fix_suggestion="Consider vectorized operations, sets, or dict lookups to reduce nesting.",
                        detected_by="ast",
                    ))
                    break  # one warning per function

        return bugs

    def _complexity_bugs(self, project: Project) -> List[Bug]:
        """Use pre-computed complexity from domain models."""
        bugs = []
        for func in project.all_functions():
            if func.complexity > self.max_complexity:
                bugs.append(Bug(
                    category=BugCategory.COMPLEXITY,
                    severity=BugSeverity.HIGH,
                    message=(
                        f"Function '{func.name}' has cyclomatic complexity {func.complexity} "
                        f"(limit: {self.max_complexity})."
                    ),
                    file_path=str(func.path),
                    line_number=func.line_start,
                    fix_suggestion="Refactor into smaller functions. Aim for complexity ≤ 10.",
                    detected_by="ast",
                ))
        return bugs

    # ---- Reporting ----

    def get_bug_summary(self, bugs: List[Bug]) -> str:
        if not bugs:
            return "✅ No issues detected."

        by_severity: dict = {}
        for bug in bugs:
            key = bug.severity
            by_severity.setdefault(key, []).append(bug)

        sev_order = [
            BugSeverity.CRITICAL, BugSeverity.HIGH,
            BugSeverity.MEDIUM, BugSeverity.LOW, BugSeverity.INFO
        ]

        total = len(bugs)
        lines = [f"🐛 Bug Report — {total} issue(s) found\n"]

        for sev in sev_order:
            if sev not in by_severity:
                continue
            group = by_severity[sev]
            lines.append(f"{'─'*50}")
            lines.append(f"[{sev.name}] — {len(group)} issue(s)")
            for bug in group[:5]:  # Show max 5 per severity
                lines.append(bug.to_report())

        if total > sum(len(v) for v in by_severity.values()):
            lines.append(f"\n... and {total - 25} more. Run with --all-bugs to see everything.")

        return "\n".join(lines)
