"""
DreamOS Agent - Dependency Analyzer
Detects import relationships, circular dependencies, and unused modules.
"""

from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

from ..core.models import Module, Project, Relationship, RelationshipType


class DependencyAnalyzer:
    """Builds import/dependency graphs from project modules."""

    def build_import_graph(self, project: Project) -> Dict[str, List[str]]:
        """Return adjacency map: module_name -> list of imported module names."""
        graph: Dict[str, List[str]] = {}
        module_names = {m.name for m in project.modules}

        for module in project.modules:
            local_imports = [imp for imp in module.imports if imp in module_names]
            graph[module.name] = local_imports

        return graph

    def detect_circular_deps(self, project: Project) -> List[List[str]]:
        """Find all cycles in the import graph using DFS."""
        graph = self.build_import_graph(project)
        visited: Set[str] = set()
        rec_stack: Set[str] = set()
        cycles: List[List[str]] = []

        def dfs(node: str, path: List[str]):
            visited.add(node)
            rec_stack.add(node)
            path.append(node)

            for neighbor in graph.get(node, []):
                if neighbor not in visited:
                    dfs(neighbor, path)
                elif neighbor in rec_stack:
                    # Found a cycle — extract it
                    cycle_start = path.index(neighbor)
                    cycles.append(path[cycle_start:] + [neighbor])

            path.pop()
            rec_stack.discard(node)

        for node in graph:
            if node not in visited:
                dfs(node, [])

        return cycles

    def find_unused_modules(self, project: Project) -> List[Module]:
        """Modules that are never imported by other modules."""
        graph = self.build_import_graph(project)
        all_imported: Set[str] = set()
        for imports in graph.values():
            all_imported.update(imports)

        unused = []
        for module in project.modules:
            if module.name not in all_imported and not module.is_entry_point:
                unused.append(module)
        return unused

    def get_relationships(self, project: Project) -> List[Relationship]:
        """Convert import graph to Relationship domain objects."""
        graph = self.build_import_graph(project)
        rels = []
        module_paths = {m.name: str(m.path) for m in project.modules}
        for source, targets in graph.items():
            for target in targets:
                rels.append(Relationship(
                    source_name=source,
                    target_name=target,
                    relationship_type=RelationshipType.IMPORTS,
                    source_file=module_paths.get(source, ""),
                    target_file=module_paths.get(target, ""),
                ))
        return rels

    def summary(self, project: Project) -> str:
        """Human-readable dependency summary."""
        graph = self.build_import_graph(project)
        cycles = self.detect_circular_deps(project)
        unused = self.find_unused_modules(project)

        lines = ["📊 Dependency Analysis"]
        lines.append(f"  Modules with local imports: {sum(1 for v in graph.values() if v)}")
        lines.append(f"  Circular dependency cycles: {len(cycles)}")
        lines.append(f"  Potentially unused modules: {len(unused)}")

        if cycles:
            lines.append("\n⚠️  Circular Dependencies:")
            for cycle in cycles[:3]:
                lines.append("  " + " → ".join(cycle))

        if unused:
            lines.append("\n🗑  Unused Modules (not imported anywhere):")
            for mod in unused[:5]:
                lines.append(f"  • {mod.name} ({Path(mod.path).name})")

        return "\n".join(lines)
