"""
DreamOS Agent - Core Domain Models
All domain entities representing code structure, bugs, and relationships.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional


# ============ Enums ============

class EntityType(Enum):
    FUNCTION = "function"
    CLASS = "class"
    MODULE = "module"
    PROJECT = "project"


class BugSeverity(Enum):
    CRITICAL = 4
    HIGH = 3
    MEDIUM = 2
    LOW = 1
    INFO = 0


class BugCategory(Enum):
    SYNTAX = "syntax_error"
    PATTERN = "pattern_bug"
    COMPLEXITY = "complexity"
    STYLE = "style"
    SECURITY = "security"
    PERFORMANCE = "performance"


class RelationshipType(Enum):
    IMPORTS = "imports"
    INHERITS = "inherits"
    CALLS = "calls"
    USES = "uses"


# ============ Base Entity ============

@dataclass
class CodeEntity:
    """Abstract base for all code entities"""
    name: str
    path: Path
    line_start: int = 0
    line_end: int = 0
    docstring: Optional[str] = None
    entity_type: EntityType = EntityType.MODULE

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "path": str(self.path),
            "line_start": self.line_start,
            "line_end": self.line_end,
            "docstring": self.docstring,
            "entity_type": self.entity_type.value,
        }


# ============ Code Entities ============

@dataclass
class Function(CodeEntity):
    """Represents a function or method"""
    args: List[str] = field(default_factory=list)
    returns: Optional[str] = None
    decorators: List[str] = field(default_factory=list)
    complexity: int = 1
    calls: List[str] = field(default_factory=list)
    is_method: bool = False
    is_async: bool = False

    def __post_init__(self):
        self.entity_type = EntityType.FUNCTION

    @property
    def signature(self) -> str:
        args_str = ", ".join(self.args)
        prefix = "async " if self.is_async else ""
        ret = f" -> {self.returns}" if self.returns else ""
        return f"{prefix}def {self.name}({args_str}){ret}"

    def to_dict(self) -> Dict[str, Any]:
        d = super().to_dict()
        d.update({
            "args": self.args,
            "returns": self.returns,
            "decorators": self.decorators,
            "complexity": self.complexity,
            "calls": self.calls,
            "is_method": self.is_method,
            "is_async": self.is_async,
        })
        return d


@dataclass
class Class(CodeEntity):
    """Represents a class definition"""
    methods: List[Function] = field(default_factory=list)
    attributes: List[str] = field(default_factory=list)
    base_classes: List[str] = field(default_factory=list)
    is_abstract: bool = False
    is_dataclass: bool = False

    def __post_init__(self):
        self.entity_type = EntityType.CLASS

    def to_dict(self) -> Dict[str, Any]:
        d = super().to_dict()
        d.update({
            "methods": [m.to_dict() for m in self.methods],
            "attributes": self.attributes,
            "base_classes": self.base_classes,
            "is_abstract": self.is_abstract,
            "is_dataclass": self.is_dataclass,
        })
        return d


@dataclass
class Module(CodeEntity):
    """Represents a source file / module"""
    imports: List[str] = field(default_factory=list)
    functions: List[Function] = field(default_factory=list)
    classes: List[Class] = field(default_factory=list)
    global_vars: List[str] = field(default_factory=list)
    is_entry_point: bool = False
    language: str = "python"

    def __post_init__(self):
        self.entity_type = EntityType.MODULE

    def all_functions(self) -> List[Function]:
        """Flatten module + class methods"""
        funcs = list(self.functions)
        for cls in self.classes:
            funcs.extend(cls.methods)
        return funcs

    def to_dict(self) -> Dict[str, Any]:
        d = super().to_dict()
        d.update({
            "imports": self.imports,
            "functions": [f.to_dict() for f in self.functions],
            "classes": [c.to_dict() for c in self.classes],
            "global_vars": self.global_vars,
            "is_entry_point": self.is_entry_point,
            "language": self.language,
        })
        return d


@dataclass
class Project(CodeEntity):
    """Top-level container for the entire codebase"""
    modules: List[Module] = field(default_factory=list)
    dependencies: Dict[str, str] = field(default_factory=dict)
    entry_points: List[str] = field(default_factory=list)
    framework: Optional[str] = None
    language: str = "python"
    analyzed_at: datetime = field(default_factory=datetime.now)

    def __post_init__(self):
        self.entity_type = EntityType.PROJECT

    def get_module_by_path(self, path: Path) -> Optional[Module]:
        for module in self.modules:
            if module.path == path:
                return module
        return None

    def all_functions(self) -> List[Function]:
        funcs = []
        for module in self.modules:
            funcs.extend(module.all_functions())
        return funcs

    def all_classes(self) -> List[Class]:
        classes = []
        for module in self.modules:
            classes.extend(module.classes)
        return classes

    def complexity_score(self) -> float:
        all_funcs = self.all_functions()
        if not all_funcs:
            return 0.0
        return sum(f.complexity for f in all_funcs) / len(all_funcs)

    def stats(self) -> Dict[str, Any]:
        return {
            "modules": len(self.modules),
            "functions": len(self.all_functions()),
            "classes": len(self.all_classes()),
            "avg_complexity": round(self.complexity_score(), 2),
            "entry_points": self.entry_points,
            "framework": self.framework,
        }

    def to_dict(self) -> Dict[str, Any]:
        d = super().to_dict()
        d.update({
            "modules": [m.to_dict() for m in self.modules],
            "dependencies": self.dependencies,
            "entry_points": self.entry_points,
            "framework": self.framework,
            "language": self.language,
            "analyzed_at": self.analyzed_at.isoformat(),
        })
        return d


# ============ Bugs ============

@dataclass
class Bug:
    """Represents a detected code issue"""
    category: BugCategory
    severity: BugSeverity
    message: str
    file_path: str
    line_number: int = 0
    snippet: str = ""
    fix_suggestion: Optional[str] = None
    detected_by: str = "auto"  # "ast", "pattern", "llm"
    created_at: datetime = field(default_factory=datetime.now)
    is_fixed: bool = False

    def to_report(self) -> str:
        sev_icons = {
            BugSeverity.CRITICAL: "🔴",
            BugSeverity.HIGH: "🟠",
            BugSeverity.MEDIUM: "🟡",
            BugSeverity.LOW: "🔵",
            BugSeverity.INFO: "⚪",
        }
        icon = sev_icons.get(self.severity, "⚪")
        lines = [
            f"{icon} [{self.severity.name}] {self.category.value}",
            f"   📍 {self.file_path}:{self.line_number}",
            f"   💬 {self.message}",
        ]
        if self.snippet:
            lines.append(f"   📝 {self.snippet[:100]}")
        if self.fix_suggestion:
            lines.append(f"   💡 Fix: {self.fix_suggestion}")
        return "\n".join(lines)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "category": self.category.value,
            "severity": self.severity.name,
            "message": self.message,
            "file_path": self.file_path,
            "line_number": self.line_number,
            "snippet": self.snippet,
            "fix_suggestion": self.fix_suggestion,
            "detected_by": self.detected_by,
        }


# ============ Relationships ============

@dataclass
class Relationship:
    """Connection between two code entities"""
    source_name: str
    target_name: str
    relationship_type: RelationshipType
    source_file: str = ""
    target_file: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "source": self.source_name,
            "target": self.target_name,
            "type": self.relationship_type.value,
            "source_file": self.source_file,
            "target_file": self.target_file,
        }


# ============ Session & Memory ============

@dataclass
class SessionContext:
    """Current conversation state"""
    session_id: str
    current_project: Optional[Project] = None
    history: List[Dict[str, str]] = field(default_factory=list)
    last_query: Optional[str] = None

    def add_message(self, role: str, content: str):
        self.history.append({"role": role, "content": content})
        if len(self.history) > 50:
            self.history = self.history[-50:]

    def get_recent_context(self, n: int = 10) -> List[Dict[str, str]]:
        return self.history[-n:]


@dataclass
class Memory:
    """Long-term storage for project insights"""
    project_path: str
    insights: List[str] = field(default_factory=list)
    learned_patterns: Dict[str, Any] = field(default_factory=dict)
    last_analyzed: datetime = field(default_factory=datetime.now)

    def add_insight(self, insight: str):
        if insight not in self.insights:
            self.insights.append(insight)
        if len(self.insights) > 100:
            self.insights = self.insights[-100:]

    def recall(self, query: str) -> List[str]:
        query_words = set(query.lower().split())
        relevant = [i for i in self.insights if any(w in i.lower() for w in query_words)]
        return relevant[:5]
