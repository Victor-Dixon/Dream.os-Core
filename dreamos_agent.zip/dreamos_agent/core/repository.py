"""
DreamOS Agent - Domain Repository
Storage and retrieval for analyzed project data.
"""

import json
import pickle
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from .models import Bug, BugCategory, BugSeverity, Function, Module, Project, Memory


CACHE_DIR = Path.home() / ".dreamos_agent" / "cache"


class DomainRepository:
    """Serializes, saves, and queries domain models."""

    def __init__(self, storage_path: Optional[Path] = None):
        self.storage = storage_path or (CACHE_DIR / "projects")
        self.storage.mkdir(parents=True, exist_ok=True)

    # ---- Save / Load ----

    def save_project(self, project: Project) -> Path:
        """Serialize project to JSON."""
        safe_name = project.name.replace("/", "_").replace("\\", "_")
        save_path = self.storage / f"{safe_name}.json"
        with open(save_path, "w", encoding="utf-8") as f:
            json.dump(project.to_dict(), f, indent=2, default=str)
        return save_path

    def save_bugs(self, project_name: str, bugs: List[Bug]) -> Path:
        safe_name = project_name.replace("/", "_")
        save_path = self.storage / f"{safe_name}.bugs.json"
        with open(save_path, "w", encoding="utf-8") as f:
            json.dump([b.to_dict() for b in bugs], f, indent=2, default=str)
        return save_path

    def load_bugs(self, project_name: str) -> List[Dict[str, Any]]:
        safe_name = project_name.replace("/", "_")
        load_path = self.storage / f"{safe_name}.bugs.json"
        if not load_path.exists():
            return []
        with open(load_path, "r", encoding="utf-8") as f:
            return json.load(f)

    def project_exists(self, name: str) -> bool:
        safe_name = name.replace("/", "_")
        return (self.storage / f"{safe_name}.json").exists()

    def list_projects(self) -> List[str]:
        return [p.stem for p in self.storage.glob("*.json") if not p.stem.endswith(".bugs")]

    # ---- Query Helpers ----

    def query_functions(
        self, project: Project, min_complexity: int = 0
    ) -> List[Function]:
        return [f for f in project.all_functions() if f.complexity >= min_complexity]

    def find_long_functions(self, project: Project, min_lines: int = 50) -> List[Function]:
        return [
            f for f in project.all_functions()
            if (f.line_end - f.line_start) >= min_lines
        ]

    def find_entry_points(self, project: Project) -> List[str]:
        return project.entry_points

    def find_modules_with_imports(self, project: Project, import_name: str) -> List[Module]:
        return [m for m in project.modules if import_name in m.imports]

    def filter_bugs(
        self, bugs: List[Bug], severity: Optional[BugSeverity] = None,
        category: Optional[BugCategory] = None
    ) -> List[Bug]:
        result = bugs
        if severity:
            result = [b for b in result if b.severity == severity]
        if category:
            result = [b for b in result if b.category == category]
        return result


class MemoryStore:
    """Persistent memory for project insights across sessions."""

    def __init__(self, storage_path: Optional[Path] = None):
        self.storage = storage_path or (CACHE_DIR / "memory")
        self.storage.mkdir(parents=True, exist_ok=True)

    def _path(self, project_name: str) -> Path:
        safe = project_name.replace("/", "_")
        return self.storage / f"{safe}.memory.json"

    def load(self, project_name: str) -> Memory:
        p = self._path(project_name)
        if p.exists():
            data = json.loads(p.read_text())
            m = Memory(project_path=project_name)
            m.insights = data.get("insights", [])
            m.learned_patterns = data.get("learned_patterns", {})
            return m
        return Memory(project_path=project_name)

    def save(self, memory: Memory):
        p = self._path(memory.project_path)
        p.write_text(json.dumps({
            "project_path": memory.project_path,
            "insights": memory.insights,
            "learned_patterns": memory.learned_patterns,
            "last_analyzed": memory.last_analyzed.isoformat(),
        }, indent=2))
