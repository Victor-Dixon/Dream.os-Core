"""
DreamOS Agent - CLI Interface
Terminal chat UI with colorized output and progress indicators.
"""

import sys
import time
from pathlib import Path


# ============ Colors (no dependencies needed) ============

class Colors:
    RESET  = "\033[0m"
    BOLD   = "\033[1m"
    DIM    = "\033[2m"
    RED    = "\033[91m"
    GREEN  = "\033[92m"
    YELLOW = "\033[93m"
    BLUE   = "\033[94m"
    CYAN   = "\033[96m"
    WHITE  = "\033[97m"
    GRAY   = "\033[90m"

def c(text: str, color: str) -> str:
    return f"{color}{text}{Colors.RESET}"

def spinner(label: str):
    """Context manager for a simple spinner."""
    import threading
    done = threading.Event()

    def spin():
        chars = "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏"
        i = 0
        while not done.is_set():
            sys.stdout.write(f"\r{chars[i % len(chars)]} {label}")
            sys.stdout.flush()
            time.sleep(0.1)
            i += 1
        sys.stdout.write(f"\r✅ {label}\n")
        sys.stdout.flush()

    t = threading.Thread(target=spin, daemon=True)

    class Ctx:
        def __enter__(self):
            t.start()
            return self
        def __exit__(self, *args):
            done.set()
            t.join()

    return Ctx()


def print_banner(project_name: str, n_modules: int, n_bugs: int):
    print()
    print(c("╔══════════════════════════════════════════╗", Colors.CYAN))
    print(c("║         🧠  DreamOS Agent  🧠            ║", Colors.CYAN + Colors.BOLD))
    print(c("╚══════════════════════════════════════════╝", Colors.CYAN))
    print(f"  Project : {c(project_name, Colors.YELLOW)}")
    print(f"  Modules : {c(str(n_modules), Colors.GREEN)}")
    print(f"  Issues  : {c(str(n_bugs), Colors.RED if n_bugs else Colors.GREEN)}")
    print(f"  Type    : {c('help', Colors.GRAY)} for commands, {c('exit', Colors.GRAY)} to quit")
    print()


def format_response(response: str) -> str:
    """Add minimal color to the response."""
    lines = []
    for line in response.splitlines():
        if line.startswith("🔴") or "CRITICAL" in line:
            lines.append(c(line, Colors.RED))
        elif line.startswith("🟠") or "[HIGH]" in line:
            lines.append(c(line, Colors.YELLOW))
        elif line.startswith("✅"):
            lines.append(c(line, Colors.GREEN))
        elif line.startswith("  •") or line.startswith("  def") or line.startswith("  class"):
            lines.append(c(line, Colors.CYAN))
        else:
            lines.append(line)
    return "\n".join(lines)


def run_cli(workspace: str = ".", model: str = "llama3", verbose: bool = True):
    """Main CLI entry point."""
    from ..agent.orchestrator import Orchestrator

    agent = Orchestrator(workspace=workspace, model=model, verbose=False)

    with spinner("Analyzing codebase"):
        agent.initialize()

    print_banner(
        project_name=agent.project.name if agent.project else workspace,
        n_modules=len(agent.project.modules) if agent.project else 0,
        n_bugs=len(agent.bugs),
    )

    while True:
        try:
            user_input = input(c("you › ", Colors.BOLD + Colors.BLUE)).strip()
        except (EOFError, KeyboardInterrupt):
            print(f"\n{c('Goodbye!', Colors.GRAY)}")
            break

        if not user_input:
            continue

        if user_input.lower() in ("exit", "quit", "q"):
            print(c("Goodbye! 👋", Colors.GRAY))
            break

        with spinner("Thinking"):
            response = agent.answer(user_input)

        print()
        print(c("agent › ", Colors.BOLD + Colors.GREEN))
        print(format_response(response))
        print()
