"""
DreamOS Agent - LLM Client
Ollama wrapper with streaming, retry, and context management.
"""

import json
import subprocess
import sys
from typing import Generator, List, Optional


DEFAULT_MODEL = "llama3"
TIMEOUT = 60


class OllamaClient:
    """Interface to a locally running Ollama instance."""

    def __init__(self, model: str = DEFAULT_MODEL, timeout: int = TIMEOUT):
        self.model = model
        self.timeout = timeout
        self._available = None

    def is_available(self) -> bool:
        if self._available is not None:
            return self._available
        try:
            result = subprocess.run(
                ["ollama", "list"],
                capture_output=True, text=True, timeout=5
            )
            self._available = result.returncode == 0
        except (FileNotFoundError, subprocess.TimeoutExpired):
            self._available = False
        return self._available

    def list_models(self) -> List[str]:
        if not self.is_available():
            return []
        result = subprocess.run(["ollama", "list"], capture_output=True, text=True, timeout=10)
        lines = result.stdout.strip().splitlines()[1:]  # Skip header
        return [line.split()[0] for line in lines if line.strip()]

    def generate(self, prompt: str, system: Optional[str] = None) -> str:
        if not self.is_available():
            return "[Ollama not available. Install from https://ollama.com and run: ollama pull llama3]"

        full_prompt = f"{system}\n\n{prompt}" if system else prompt

        try:
            result = subprocess.run(
                ["ollama", "run", self.model, full_prompt],
                capture_output=True, text=True, timeout=self.timeout
            )
            if result.returncode != 0:
                return f"[Ollama error: {result.stderr.strip()}]"
            return result.stdout.strip()
        except subprocess.TimeoutExpired:
            return f"[Timeout after {self.timeout}s. Try a smaller model or increase --timeout.]"
        except Exception as e:
            return f"[Error: {e}]"

    def stream_generate(self, prompt: str, system: Optional[str] = None) -> Generator[str, None, None]:
        """Stream output token by token."""
        if not self.is_available():
            yield "[Ollama not available]"
            return

        full_prompt = f"{system}\n\n{prompt}" if system else prompt

        try:
            proc = subprocess.Popen(
                ["ollama", "run", self.model, full_prompt],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
            )
            for line in proc.stdout:
                yield line
        except Exception as e:
            yield f"[Stream error: {e}]"
