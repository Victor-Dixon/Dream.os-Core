"""
DreamOS Agent - Prompt Templates
Structured prompts for different analysis tasks.
"""

SYSTEM_PROMPT = """You are DreamOS Agent — a local AI assistant deeply integrated with the user's codebase.

You have access to:
- Full project architecture (AST-parsed: functions, classes, imports)
- Automatic bug detection results
- Dependency analysis
- File structure

When answering:
1. Reference specific files and line numbers when relevant
2. Explain architectural patterns concisely
3. Suggest concrete, actionable fixes for bugs
4. Be direct — the user is a developer, skip obvious explanations
5. If you're unsure, say so rather than guessing

You are acting as a senior engineer who knows this codebase inside-out.
"""

ARCHITECTURE_PROMPT = """Based on the project analysis below, answer the user's question about architecture.

PROJECT ANALYSIS:
{architecture}

DEPENDENCY SUMMARY:
{dependencies}

USER QUESTION:
{query}

Provide a clear, specific answer referencing the actual code structure above.
"""

BUG_ANALYSIS_PROMPT = """You are reviewing automatically detected bugs. Provide deeper analysis.

BUG REPORT:
{bug_report}

USER QUESTION:
{query}

Explain the bugs in context and suggest prioritized fixes. Be specific about which ones matter most.
"""

CODE_EXPLANATION_PROMPT = """Explain this code component based on the project context.

PROJECT CONTEXT:
{architecture}

COMPONENT TO EXPLAIN:
{component}

USER QUESTION:
{query}

Explain what it does, why it exists, and how it fits into the larger system.
"""

GENERAL_PROMPT = """PROJECT ARCHITECTURE:
{architecture}

BUG SUMMARY:
{bug_summary}

USER QUESTION:
{query}

Answer specifically and reference actual code components from the analysis above.
"""


def build_prompt(
    query: str,
    architecture: str = "",
    bug_summary: str = "",
    dependencies: str = "",
    component: str = "",
    prompt_type: str = "general",
) -> str:
    """Select and fill the appropriate prompt template."""
    q = query.lower()

    if any(w in q for w in ["architect", "structure", "overview", "how does", "what does this"]):
        return ARCHITECTURE_PROMPT.format(
            architecture=architecture,
            dependencies=dependencies,
            query=query,
        )
    elif any(w in q for w in ["bug", "error", "issue", "problem", "fix", "wrong"]):
        return BUG_ANALYSIS_PROMPT.format(bug_report=bug_summary, query=query)
    elif any(w in q for w in ["explain", "what is", "describe", "tell me about"]) and component:
        return CODE_EXPLANATION_PROMPT.format(
            architecture=architecture, component=component, query=query
        )
    else:
        return GENERAL_PROMPT.format(
            architecture=architecture, bug_summary=bug_summary, query=query
        )


def truncate_for_token_limit(text: str, max_chars: int = 8000) -> str:
    """Rough token guard — truncate long context."""
    if len(text) <= max_chars:
        return text
    half = max_chars // 2
    return text[:half] + "\n\n... [truncated for context limit] ...\n\n" + text[-half:]
