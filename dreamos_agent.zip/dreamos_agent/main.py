"""
DreamOS Agent - Main Entry Point
"""

import argparse
import sys
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(
        description="DreamOS Agent — Local AI codebase analyst",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python main.py                        # Analyze current directory
  python main.py --workspace ~/myapp    # Analyze a specific project
  python main.py --model codellama      # Use a different Ollama model
  python main.py --no-llm               # Bug detection only (no Ollama needed)
        """
    )
    parser.add_argument("--workspace", "-w", default=".", help="Path to the project to analyze")
    parser.add_argument("--model", "-m", default="llama3", help="Ollama model to use")
    parser.add_argument("--no-llm", action="store_true", help="Skip LLM, show analysis only")
    parser.add_argument("--bugs-only", action="store_true", help="Print bug report and exit")
    parser.add_argument("--arch-only", action="store_true", help="Print architecture summary and exit")

    args = parser.parse_args()

    workspace = str(Path(args.workspace).resolve())

    if args.no_llm or args.bugs_only or args.arch_only:
        # Headless mode — just print results
        from dreamos_agent.analyzers import ASTAnalyzer, BugDetector, DependencyAnalyzer

        print(f"🔍 Analyzing {workspace}...")
        analyzer = ASTAnalyzer(workspace)
        project = analyzer.analyze_project()
        arch = analyzer.get_architecture_summary(project)

        if args.arch_only or args.no_llm:
            print("\n" + arch)
            dep = DependencyAnalyzer().summary(project)
            print("\n" + dep)

        if args.bugs_only or args.no_llm:
            bugs = BugDetector().scan_project(project)
            summary = BugDetector().get_bug_summary(bugs)
            print("\n" + summary)

        return

    # Full interactive mode
    from dreamos_agent.interfaces.cli import run_cli
    run_cli(workspace=workspace, model=args.model)


if __name__ == "__main__":
    main()
