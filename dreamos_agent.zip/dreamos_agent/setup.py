from setuptools import setup, find_packages

setup(
    name="dreamos-agent",
    version="1.0.0",
    description="Local AI codebase analyst — understands your code without the cloud",
    packages=find_packages(),
    python_requires=">=3.10",
    entry_points={
        "console_scripts": [
            "dreamos=dreamos_agent.main:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3.10",
        "License :: OSI Approved :: MIT License",
        "Topic :: Software Development :: Libraries",
    ],
)
