"""Tests for the AST analyzer."""

import os
import tempfile
from pathlib import Path

import pytest
from dreamos_agent.analyzers.ast_analyzer import ASTAnalyzer


def write_temp(content: str) -> Path:
    f = tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False, dir="/tmp")
    f.write(content)
    f.close()
    return Path(f.name)


def make_project_dir(files: dict) -> Path:
    """Create a temp dir with given filename→content mapping."""
    d = Path(tempfile.mkdtemp())
    for name, content in files.items():
        (d / name).write_text(content)
    return d


class TestASTAnalyzer:

    def test_parse_function(self):
        p = write_temp("def greet(name: str) -> str:\n    return f'Hello {name}'\n")
        analyzer = ASTAnalyzer(str(p.parent))
        module = analyzer.parse_file(p)
        os.unlink(p)
        assert module is not None
        assert any(f.name == "greet" for f in module.functions)

    def test_parse_function_args(self):
        p = write_temp("def add(a, b, c=0):\n    return a + b + c\n")
        analyzer = ASTAnalyzer(str(p.parent))
        module = analyzer.parse_file(p)
        os.unlink(p)
        func = module.functions[0]
        assert "a" in func.args
        assert "b" in func.args

    def test_parse_async_function(self):
        p = write_temp("async def fetch(url):\n    pass\n")
        analyzer = ASTAnalyzer(str(p.parent))
        module = analyzer.parse_file(p)
        os.unlink(p)
        func = module.functions[0]
        assert func.is_async is True

    def test_parse_class(self):
        p = write_temp(
            "class Animal:\n    def speak(self):\n        pass\n"
        )
        analyzer = ASTAnalyzer(str(p.parent))
        module = analyzer.parse_file(p)
        os.unlink(p)
        assert any(c.name == "Animal" for c in module.classes)
        cls = module.classes[0]
        assert any(m.name == "speak" for m in cls.methods)

    def test_parse_class_inheritance(self):
        p = write_temp("class Dog(Animal):\n    pass\n")
        analyzer = ASTAnalyzer(str(p.parent))
        module = analyzer.parse_file(p)
        os.unlink(p)
        cls = module.classes[0]
        assert "Animal" in cls.base_classes

    def test_parse_imports(self):
        p = write_temp("import os\nfrom pathlib import Path\n")
        analyzer = ASTAnalyzer(str(p.parent))
        module = analyzer.parse_file(p)
        os.unlink(p)
        assert "os" in module.imports
        assert "pathlib" in module.imports

    def test_complexity_if_branch(self):
        code = (
            "def check(x):\n"
            "    if x > 0:\n"
            "        return True\n"
            "    elif x < 0:\n"
            "        return False\n"
            "    return None\n"
        )
        p = write_temp(code)
        analyzer = ASTAnalyzer(str(p.parent))
        module = analyzer.parse_file(p)
        os.unlink(p)
        func = module.functions[0]
        assert func.complexity >= 2

    def test_parse_syntax_error(self):
        p = write_temp("def broken(\n    x\n")
        analyzer = ASTAnalyzer(str(p.parent))
        module = analyzer.parse_file(p)
        os.unlink(p)
        assert module is not None
        assert "SyntaxError" in (module.docstring or "")

    def test_entry_point_detection(self):
        p = write_temp("def main():\n    pass\n")
        analyzer = ASTAnalyzer(str(p.parent))
        module = analyzer.parse_file(p)
        os.unlink(p)
        assert module.is_entry_point is True

    def test_analyze_project(self):
        d = make_project_dir({
            "alpha.py": "def foo():\n    pass\n",
            "beta.py": "class Bar:\n    def baz(self):\n        pass\n",
        })
        analyzer = ASTAnalyzer(str(d))
        project = analyzer.analyze_project()
        assert len(project.modules) == 2
        assert project.name == d.name

    def test_architecture_summary(self):
        d = make_project_dir({
            "main.py": "def main():\n    pass\n",
        })
        analyzer = ASTAnalyzer(str(d))
        project = analyzer.analyze_project()
        summary = analyzer.get_architecture_summary(project)
        assert "Project" in summary
        assert "Functions" in summary
