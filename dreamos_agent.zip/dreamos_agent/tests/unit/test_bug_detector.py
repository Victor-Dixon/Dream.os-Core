"""Tests for the bug detector."""

import pytest
from pathlib import Path
import tempfile
import os

from dreamos_agent.analyzers.bug_detector import BugDetector
from dreamos_agent.core.models import BugCategory, BugSeverity


def write_temp(content: str, suffix=".py") -> Path:
    f = tempfile.NamedTemporaryFile(mode="w", suffix=suffix, delete=False)
    f.write(content)
    f.close()
    return Path(f.name)


class TestBugDetector:
    def setup_method(self):
        self.detector = BugDetector()

    def teardown_method(self):
        pass  # temp files cleaned per test

    def test_bare_except_detected(self):
        p = write_temp("try:\n    pass\nexcept:\n    pass\n")
        bugs = self.detector.scan_file(p)
        os.unlink(p)
        types = [b.category for b in bugs]
        assert BugCategory.PATTERN in types

    def test_mutable_default_list(self):
        p = write_temp("def foo(x=[]):\n    pass\n")
        bugs = self.detector.scan_file(p)
        os.unlink(p)
        assert any("Mutable default" in b.message for b in bugs)

    def test_mutable_default_dict(self):
        p = write_temp("def bar(opts={}):\n    pass\n")
        bugs = self.detector.scan_file(p)
        os.unlink(p)
        assert any("Mutable default" in b.message for b in bugs)

    def test_hardcoded_password(self):
        p = write_temp('password = "supersecret123"\n')
        bugs = self.detector.scan_file(p)
        os.unlink(p)
        assert any(b.severity == BugSeverity.CRITICAL for b in bugs)

    def test_hardcoded_api_key(self):
        p = write_temp('api_key = "sk-abc123"\n')
        bugs = self.detector.scan_file(p)
        os.unlink(p)
        assert any(b.category == BugCategory.SECURITY for b in bugs)

    def test_eval_detected(self):
        p = write_temp('result = eval(user_input)\n')
        bugs = self.detector.scan_file(p)
        os.unlink(p)
        assert any("eval" in b.message.lower() for b in bugs)

    def test_syntax_error_detected(self):
        p = write_temp("def broken(\n    pass\n")
        bugs = self.detector.scan_file(p)
        os.unlink(p)
        assert any(b.category == BugCategory.SYNTAX for b in bugs)

    def test_long_function_detected(self):
        body = "def big_func():\n" + "    x = 1\n" * 60
        p = write_temp(body)
        bugs = self.detector.scan_file(p)
        os.unlink(p)
        assert any("lines long" in b.message for b in bugs)

    def test_clean_file_no_bugs(self):
        p = write_temp(
            'def add(a: int, b: int) -> int:\n    """Add two numbers."""\n    return a + b\n'
        )
        bugs = self.detector.scan_file(p)
        os.unlink(p)
        # May have print-related false positives but no critical/high
        high_plus = [b for b in bugs if b.severity.value >= BugSeverity.HIGH.value]
        assert len(high_plus) == 0

    def test_bug_summary_no_bugs(self):
        summary = self.detector.get_bug_summary([])
        assert "No issues" in summary

    def test_bug_summary_with_bugs(self):
        from dreamos_agent.core.models import Bug
        bugs = [Bug(
            category=BugCategory.PATTERN,
            severity=BugSeverity.HIGH,
            message="Bare except",
            file_path="app.py",
            line_number=1,
        )]
        summary = self.detector.get_bug_summary(bugs)
        assert "Bug Report" in summary
        assert "HIGH" in summary
