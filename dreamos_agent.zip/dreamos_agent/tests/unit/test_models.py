"""Tests for core domain models."""

import pytest
from pathlib import Path
from dreamos_agent.core.models import (
    Function, Class, Module, Project,
    Bug, BugCategory, BugSeverity, EntityType,
)


def make_function(name="my_func", complexity=1):
    return Function(
        name=name, path=Path("test.py"),
        line_start=1, line_end=10,
        args=["a", "b"], complexity=complexity,
    )

def make_module(name="mymod"):
    mod = Module(name=name, path=Path(f"{name}.py"))
    mod.functions = [make_function("foo"), make_function("bar")]
    return mod

def make_project():
    p = Project(name="testproject", path=Path("."))
    p.modules = [make_module("alpha"), make_module("beta")]
    return p


class TestFunction:
    def test_entity_type(self):
        f = make_function()
        assert f.entity_type == EntityType.FUNCTION

    def test_signature_no_return(self):
        f = make_function("greet")
        f.args = ["name"]
        assert f.signature == "def greet(name)"

    def test_signature_with_return(self):
        f = make_function("add")
        f.args = ["x", "y"]
        f.returns = "int"
        assert f.signature == "def add(x, y) -> int"

    def test_async_signature(self):
        f = make_function("fetch")
        f.is_async = True
        assert f.signature.startswith("async def")

    def test_to_dict(self):
        f = make_function("calc")
        d = f.to_dict()
        assert d["name"] == "calc"
        assert "complexity" in d


class TestProject:
    def test_all_functions_flattened(self):
        p = make_project()
        funcs = p.all_functions()
        assert len(funcs) == 4  # 2 modules × 2 functions

    def test_complexity_score(self):
        p = make_project()
        assert p.complexity_score() == 1.0

    def test_complexity_with_high_func(self):
        p = make_project()
        p.modules[0].functions[0].complexity = 9
        score = p.complexity_score()
        assert score > 1.0

    def test_stats_keys(self):
        p = make_project()
        stats = p.stats()
        assert "modules" in stats
        assert "functions" in stats
        assert "avg_complexity" in stats

    def test_get_module_by_path(self):
        p = make_project()
        mod = p.modules[0]
        found = p.get_module_by_path(mod.path)
        assert found is mod

    def test_get_module_by_path_missing(self):
        p = make_project()
        assert p.get_module_by_path(Path("nope.py")) is None


class TestBug:
    def test_to_report_contains_severity(self):
        bug = Bug(
            category=BugCategory.SECURITY,
            severity=BugSeverity.CRITICAL,
            message="Hardcoded password",
            file_path="config.py",
            line_number=5,
        )
        report = bug.to_report()
        assert "CRITICAL" in report
        assert "config.py" in report

    def test_to_dict(self):
        bug = Bug(
            category=BugCategory.PATTERN,
            severity=BugSeverity.HIGH,
            message="Bare except",
            file_path="app.py",
            line_number=10,
        )
        d = bug.to_dict()
        assert d["severity"] == "HIGH"
        assert d["file_path"] == "app.py"
