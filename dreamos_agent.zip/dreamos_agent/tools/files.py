"""
DreamOS Agent - File Tool
Safe file reading and editing with backup support.
"""

import shutil
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Tuple


class FileTool:
    """Read, write, and edit files safely within the workspace."""

    def __init__(self, workspace: str = "."):
        self.workspace = Path(workspace).resolve()

    def _resolve(self, path: str) -> Path:
        """Resolve path within workspace (prevents traversal)."""
        resolved = (self.workspace / path).resolve()
        if not str(resolved).startswith(str(self.workspace)):
            raise PermissionError(f"Path '{path}' is outside the workspace.")
        return resolved

    def read(self, path: str, line_start: Optional[int] = None, line_end: Optional[int] = None) -> str:
        """Read a file, optionally a specific line range."""
        p = self._resolve(path)
        if not p.exists():
            return f"[Error: {path} does not exist]"
        if not p.is_file():
            return f"[Error: {path} is not a file]"

        content = p.read_text(encoding="utf-8", errors="replace")

        if line_start is not None:
            lines = content.splitlines()
            start = max(0, line_start - 1)
            end = line_end if line_end else len(lines)
            selected = lines[start:end]
            return "\n".join(f"{start+i+1:4}  {line}" for i, line in enumerate(selected))

        return content

    def write(self, path: str, content: str, backup: bool = True) -> str:
        """Write content to a file, with optional backup."""
        p = self._resolve(path)
        if backup and p.exists():
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = p.with_suffix(f".{ts}.bak")
            shutil.copy2(p, backup_path)

        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        return f"✅ Written to {path}"

    def edit(self, path: str, line_start: int, line_end: int, new_content: str, backup: bool = True) -> str:
        """Replace a range of lines in a file."""
        p = self._resolve(path)
        if not p.exists():
            return f"[Error: {path} not found]"

        lines = p.read_text(encoding="utf-8", errors="replace").splitlines(keepends=True)
        if backup:
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            shutil.copy2(p, p.with_suffix(f".{ts}.bak"))

        new_lines = new_content.splitlines(keepends=True)
        if not new_content.endswith("\n"):
            if new_lines:
                new_lines[-1] += "\n"

        updated = lines[:line_start - 1] + new_lines + lines[line_end:]
        p.write_text("".join(updated), encoding="utf-8")
        return f"✅ Edited lines {line_start}-{line_end} in {path}"

    def list_dir(self, path: str = ".", extensions: Optional[List[str]] = None) -> str:
        """List files in a directory."""
        p = self._resolve(path)
        if not p.is_dir():
            return f"[Error: {path} is not a directory]"

        files = sorted(p.iterdir())
        lines = []
        for f in files:
            if extensions and f.suffix not in extensions:
                continue
            marker = "📁" if f.is_dir() else "📄"
            size = f.stat().st_size if f.is_file() else 0
            lines.append(f"{marker} {f.name:<40} {size:>8} bytes" if f.is_file() else f"{marker} {f.name}/")

        return "\n".join(lines) if lines else "(empty)"

    def search(self, pattern: str, path: str = ".", extensions: Optional[List[str]] = None) -> str:
        """Simple text search across files."""
        p = self._resolve(path)
        results = []
        glob = "**/*" if p.is_dir() else path

        for filepath in p.rglob("*"):
            if not filepath.is_file():
                continue
            if extensions and filepath.suffix not in extensions:
                continue
            try:
                content = filepath.read_text(encoding="utf-8", errors="replace")
                for i, line in enumerate(content.splitlines(), 1):
                    if pattern.lower() in line.lower():
                        rel = filepath.relative_to(self.workspace)
                        results.append(f"{rel}:{i}  {line.strip()}")
                        if len(results) >= 50:
                            results.append("... (truncated at 50 matches)")
                            return "\n".join(results)
            except Exception:
                continue

        return "\n".join(results) if results else f"No matches for '{pattern}'"
