"""
DreamOS Agent - Git Tool
Blame, diff, log, and history integration.
"""

import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional


@dataclass
class BlameResult:
    line_number: int
    author: str
    date: str
    commit: str
    content: str


class GitTool:
    """Git integration — blame, diff, log."""

    def __init__(self, workspace: str = "."):
        self.workspace = workspace

    def _run(self, *args) -> str:
        try:
            result = subprocess.run(
                ["git", *args],
                cwd=self.workspace,
                capture_output=True, text=True, timeout=15
            )
            if result.returncode != 0:
                return f"[git error: {result.stderr.strip()}]"
            return result.stdout.strip()
        except FileNotFoundError:
            return "[git not found in PATH]"
        except subprocess.TimeoutExpired:
            return "[git command timed out]"

    def is_git_repo(self) -> bool:
        result = self._run("rev-parse", "--is-inside-work-tree")
        return result == "true"

    def blame(self, filepath: str, line: Optional[int] = None) -> str:
        """Show who last changed each line (or a specific line)."""
        args = ["blame", "--line-porcelain", filepath]
        output = self._run(*args)
        if output.startswith("["):
            return output
        if line:
            # Parse and return just that line's blame
            lines = output.split("\n")
            return "\n".join(lines[:20])  # simplified
        return output[:2000]  # cap output

    def log(self, filepath: Optional[str] = None, n: int = 10) -> str:
        """Show recent commit log."""
        args = ["log", f"-{n}", "--oneline", "--pretty=format:%h  %ad  %an  %s", "--date=short"]
        if filepath:
            args += ["--", filepath]
        return self._run(*args)

    def diff(self, commit1: str = "HEAD~1", commit2: str = "HEAD", filepath: Optional[str] = None) -> str:
        """Show diff between commits."""
        args = ["diff", commit1, commit2]
        if filepath:
            args += ["--", filepath]
        output = self._run(*args)
        return output[:3000] if len(output) > 3000 else output

    def status(self) -> str:
        return self._run("status", "--short")

    def current_branch(self) -> str:
        return self._run("branch", "--show-current")

    def find_commits(self, pattern: str) -> str:
        """Search commit messages for a pattern."""
        return self._run("log", "--oneline", f"--grep={pattern}", "-20")
