"""
DreamOS Agent - Shell Tool
Safe command execution with whitelist, timeout, and confirmation prompts.
"""

import shlex
import subprocess
from dataclasses import dataclass
from typing import List, Optional


SAFE_COMMANDS = {
    "ls", "cat", "head", "tail", "grep", "find", "wc", "echo",
    "python", "python3", "pip", "node", "npm", "yarn",
    "git", "pytest", "ruff", "black", "mypy", "flake8",
    "tree", "pwd", "which", "env", "printenv",
}

DANGEROUS_PATTERNS = [
    "rm -rf",
    "rm -r /",
    "dd if=/dev/",
    "mkfs",
    "chmod 777",
    "chmod 000",
    "> /dev/sda",
    ":(){ :|:& };:",  # fork bomb
    "shutdown",
    "reboot",
    "format",
]


@dataclass
class CommandResult:
    command: str
    stdout: str
    stderr: str
    returncode: int
    timed_out: bool = False

    @property
    def success(self) -> bool:
        return self.returncode == 0 and not self.timed_out

    def display(self) -> str:
        parts = []
        if self.stdout:
            parts.append(self.stdout)
        if self.stderr:
            parts.append(f"[stderr] {self.stderr}")
        if self.timed_out:
            parts.append("[Command timed out]")
        if not self.success and not self.timed_out:
            parts.append(f"[Exit code: {self.returncode}]")
        return "\n".join(parts) or "(no output)"


class ShellTool:
    """Execute shell commands safely."""

    def __init__(self, workspace: str = ".", timeout: int = 30, require_confirmation: bool = True):
        self.workspace = workspace
        self.timeout = timeout
        self.require_confirmation = require_confirmation

    def is_safe(self, command: str) -> bool:
        """Check command against safety rules."""
        cmd_lower = command.lower().strip()
        for pattern in DANGEROUS_PATTERNS:
            if pattern in cmd_lower:
                return False
        # Check first token is in safelist
        try:
            parts = shlex.split(command)
            return parts[0] in SAFE_COMMANDS if parts else False
        except Exception:
            return False

    def run(self, command: str, confirm: bool = False) -> CommandResult:
        """Execute a command, with optional confirmation and safety check."""
        if not self.is_safe(command):
            if self.require_confirmation and not confirm:
                return CommandResult(
                    command=command,
                    stdout="",
                    stderr=f"⚠️ Command blocked: '{command}' is not in the safe command list. "
                           "Pass confirm=True to override.",
                    returncode=1,
                )

        try:
            result = subprocess.run(
                command,
                shell=True,
                cwd=self.workspace,
                capture_output=True,
                text=True,
                timeout=self.timeout,
            )
            return CommandResult(
                command=command,
                stdout=result.stdout,
                stderr=result.stderr,
                returncode=result.returncode,
            )
        except subprocess.TimeoutExpired:
            return CommandResult(
                command=command,
                stdout="",
                stderr=f"Command timed out after {self.timeout}s.",
                returncode=124,
                timed_out=True,
            )
        except Exception as e:
            return CommandResult(
                command=command,
                stdout="",
                stderr=str(e),
                returncode=1,
            )
